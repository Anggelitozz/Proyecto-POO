
public abstract class ZonaResidencial
{
    private String nombreZona;
    private Persona encargado;
    
    public ZonaResidencial(String nombreZona, Persona encargado){
    this.nombreZona=nombreZona;
    this.encargado=encargado;
    }

    
}
